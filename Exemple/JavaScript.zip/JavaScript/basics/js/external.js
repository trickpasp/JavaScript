document.write("External Document") 
document.write("External Document")